# My Savings Tracker — Android app

A simple savings tracker for Android. The interface is an HTML page bundled inside a WebView app. Entries and goals are stored on the device.

## Features
- Add, edit and delete savings entries (UGX), with an optional note
- Calendar view by month; tap a day to log a deposit for it
- Totals for this month and this week, with a weekly goal progress bar
- Weekly and monthly goals
- Export all entries to a CSV file saved in your Downloads folder

## Build the APK (no Android Studio needed)
1. Create a GitHub repository and push this project to the `main` branch (or open the repo and run the workflow manually).
2. Open the **Actions** tab, select **Build My Savings APK**, and wait for it to finish.
3. Download the `My-Savings-debug-APK` artifact and unzip it to get `app-debug.apk`.
4. Copy the APK to your Android phone, open it, and allow installs from that source when asked.

Build settings: application ID `com.example.mysavingstracker`, minimum Android 6.0 (API 23), target SDK 35, Java 17, Gradle 8.9.

## Build in Android Studio (optional)
Open the project folder in Android Studio, let it sync, then choose **Build > Build APK(s)**.

## Important notes
- Your savings are stored only on this device, inside the app's own storage. Uninstalling the app or clearing its data erases them. Use **Export CSV** regularly to keep a backup.
- The app does not connect to MTN Mobile Money or any bank, and it does not move money. It only records what you enter.
- This is a debug-signed build for personal use. For Google Play you would need a signed release build.
- A launcher icon has not been added yet; Android will show a default icon.
